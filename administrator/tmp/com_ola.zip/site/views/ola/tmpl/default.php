<?php
// Sem acesso direto ao arquivo
defined('_JEXEC') or die('Restricted access');
?>
<h1><?php echo $this->msg; ?></h1>