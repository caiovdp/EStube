<?php
// Sem acesso direto ao arquivo
defined('_JEXEC') or die('Restricted access');
 
// Importar a bliblioteca do controlador do Joomla
jimport('joomla.application.component.controller');
 
/**
 * Ola Component Controller
 */
class OlaController extends JController
{
} 
